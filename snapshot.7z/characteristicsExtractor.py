import cv2
import numpy as np
from functools import reduce
import math
from random import *


def centerOfMass(img):
    indexes = np.where(img==[0,0,0])
    meanY = reduce(lambda x, y: x+y,indexes[0]) / len(indexes[0])
    meanX = reduce(lambda x, y: x+y,indexes[1])  / len(indexes[1])
    return (meanY,meanX)
    
def aspectRatio(img):
    indexes = np.where(img==[0,0,0])
    aspectRatio = (max(indexes[1])-min(indexes[1])) / (max(indexes[0])-min(indexes[0]))
    return aspectRatio

def occupancyRatio(img):
    aux = np.where(img==[0,0,0])
    occupancyRatio = len(aux[1])/( (max(aux[1])-min(aux[1])) * (max(aux[0])-min(aux[0])))
    return occupancyRatio

def densityRatio(img):    
    aux = np.where(img==[0,0,0])
    meanX = math.floor( (max(aux[1])+min(aux[1]))/2  )
    leftPixels = len(list(filter(lambda x: x < meanX, aux[1])))
    rightPixels = len(aux[1])-leftPixels
    return leftPixels/rightPixels





def verticalS2(img,x0,x1,y0,y1,iterations):
    print(iterations, " verticalS")
    cv2.imwrite('test'+str(iterations)+'_'+str(random())+'_V.png',img[y0:y1,x0:x1])
    if (iterations > 0):
        center = centerOfMass(img[y0:y1,x0:x1])
        center = (math.floor(center[0])+y0,math.floor(center[1])+x0 )
        print (center)
        leftSubdivision =  horizontalS2(img,x0,center[1],y0,y1, iterations - 1)

        rightSubdivision = horizontalS2(img,center[1]+1,x1,y0,y1,iterations - 1)
        
        return [center] + leftSubdivision + rightSubdivision
    return []

def horizontalS2(img,x0,x1,y0,y1,iterations):
    cv2.imwrite('test'+str(iterations)+'_'+str(random())+'_H.png',img[y0:y1,x0:x1])
    cv2.imshow('res',img)
    if (iterations > 0):
        center = centerOfMass(img[y0:y1,x0:x1])
        center = (math.floor(center[0])+y0,math.floor(center[1])+x0 )
        print (center)
        
        topSubdivision =  verticalS2(img,x0,x1,y0,center[0], iterations - 1)
        
        bottomSubdivision = verticalS2(img,x0,x1,center[0]+1,y1,iterations - 1)
        
        return [center] + topSubdivision + bottomSubdivision
    return []


def verticalS(img,x0,x1,y0,y1,iterations):
    print(iterations, " verticalS")
    cv2.imwrite('test'+str(iterations)+'_'+str(random())+'_V.png',img)
    if (iterations > 0):
        center = centerOfMass(img)
        center = (math.floor(center[0]),math.floor(center[1]))
        print (center)
        leftSubdivision =  horizontalS(img[y0:y1,x0:center[1]],x0,center[1],y0,y1, iterations - 1)

        rightSubdivision = horizontalS(img[y0:y1,center[1]+1:x1],center[1]+1,x1,y0,y1,iterations - 1)
        
        return [center] + leftSubdivision + rightSubdivision
    return []

def horizontalS(img,x0,x1,y0,y1,iterations):
    cv2.imwrite('test'+str(iterations)+'_'+str(random())+'_H.png',img)
    cv2.imshow('res',img)
    if (iterations > 0):
        center = centerOfMass(img)
        center = (math.floor(center[0]),math.floor(center[1]))
        print (center)
        
        topSubdivision =  verticalS(img[y0:center[0],x0:x1],x0,x1,y0,center[0], iterations - 1)
        
        bottomSubdivision = verticalS(img[center[0]+1:y1,x0:x1],x0,x1,center[0]+1,y1,iterations - 1)
        
        return [center] + topSubdivision + bottomSubdivision
    return []