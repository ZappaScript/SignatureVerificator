import cv2 as cv
import numpy as np
for i in range(1,41):
    for x in range(1,41):
        with open('U'+str(i)+'S'+str(x)+'.TXT') as f:
            numPoints = int(f.readline())
            img = []
            minX = 999999999
            maxX = 0
            minY = 999999999
            maxY= 0
            for points in range(0,numPoints):
                line = f.readline().split(" ")
                ##print(line,line[1])
                if (int(line[0])<=minX):
                        minX = int(line[0])
                if (int(line[1])<=minY):
                        minY = int(line[1])
                if (int(line[0])>=maxX):
                        maxX = int(line[0])
                if (int(line[1])>=minY):
                        maxY = int(line[1])
                img.append((int(line[1]),int(line[0])))
            imgBuffer= np.ones((maxY*2,maxX*2))
            imgBuffer
            for point in range(0,len(img)):
                imgBuffer[img[point][0]-1][img[point][1]-1] == 0
            res = cv.imwrite('U'+str(i)+'S'+str(x)+'.png',imgBuffer)
            print (res)
