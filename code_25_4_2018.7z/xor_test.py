
import cv2
import numpy as np



def cropAndResize(img):
    ##imgF = cv2.imread(route+subroute1,1)
    ##imgG = cv2.imread(route+subroute2,1)


    bbImgF = np.where((img == [0,0,0]).all(axis = 2))
    cropImgF = img[min(bbImgF[0]):max(bbImgF[0]),min(bbImgF[1]):max(bbImgF[1])]
    res = cv2.resize(cropImgF,(500,200), interpolation = cv2.INTER_NEAREST)
    res = cv2.copyMakeBorder(res, 8, 8, 20, 20, cv2.BORDER_CONSTANT,None, [255,255,255]) 
    return res

def denoisingThinning(img):
    kernel2 = np.ones((2,2),np.uint8)
    img = cv2.dilate(img,kernel2,iterations=1)
    img = cv2.erode(img,kernel2,iterations=1)
    return img


def xOr(routeG, routeF, routeDisk):
    
    ##print(routeG[0:-4],routeF)

    imgG = cv2.imread(routeDisk+routeG[0:-4]+'-M2t.png',1)
    imgF = cv2.imread(routeDisk+routeF,1)
    imgF = denoisingThinning(imgF)
    imgF = cropAndResize(imgF)

    res = cv2.bitwise_xor(imgG,imgF)
    print(routeG[4:-4]+'-'+routeF[4:-4])
    print(  len(res[ np.where((res == [0,0,0]).all(axis = 2))]) )
    print(  len(res[ np.where((res == [255,255,255]).all(axis = 2))]) )
    print(  len(res[ np.where((res == [155,159,255]).all(axis = 2))]) )
    print(  len(res[ np.where((res == [0,0,255]).all(axis = 2))]) )
    print(  len(res[ np.where((res == [100,96,0]).all(axis = 2))]) )
    
    cv2.imwrite(routeDisk+routeG[0:-4]+'-'+routeF[4:-4]+'xor.png',res)



route = 'BHSig260/Hindi/'
with open(route + 'Hindi_pairs.txt') as f:
    for i in range(24):
        line=f.readline().split()
        xOr(routeF=line[1],routeG=line[0],routeDisk=route)
        ##print (line)
   