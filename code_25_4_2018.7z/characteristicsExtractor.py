import cv2
import numpy as np
from functools import reduce
import math
from random import *


def centerOfMass(img):
    indexes = np.where(img==[0,0,0])
    meanY = reduce(lambda x, y: x+y,indexes[0]) / len(indexes[0])
    meanX = reduce(lambda x, y: x+y,indexes[1])  / len(indexes[1])
    return (meanY,meanX)
    
def aspectRatio(img):
    indexes = np.where(img==[0,0,0])
    aspectRatio = (max(indexes[1])-min(indexes[1])) / (max(indexes[0])-min(indexes[0]))
    return aspectRatio

def occupancyRatio(img):
    aux = np.where(img==[0,0,0])
    occupancyRatio = len(aux[1])/( (max(aux[1])-min(aux[1])) * (max(aux[0])-min(aux[0])))
    return occupancyRatio

def densityRatio(img):    
    aux = np.where(img==[0,0,0])
    meanX = math.floor( (max(aux[1])+min(aux[1]))/2  )
    leftPixels = len(list(filter(lambda x: x < meanX, aux[1])))
    rightPixels = len(aux[1])-leftPixels
    return leftPixels/rightPixels

def verticalS2(img,x0,x1,y0,y1,iterations):
    if (iterations > 0):
        center = centerOfMass(img[y0:y1,x0:x1])
        center = (math.floor(center[0])+y0,math.floor(center[1])+x0 )
        leftSubdivision =  horizontalS2(img,x0,center[1],y0,y1, iterations - 1)
        rightSubdivision = horizontalS2(img,center[1]+1,x1,y0,y1,iterations - 1)
        return [center] + leftSubdivision + rightSubdivision
    return []

def horizontalS2(img,x0,x1,y0,y1,iterations):
    if (iterations > 0):
        center = centerOfMass(img[y0:y1,x0:x1])
        center = (math.floor(center[0])+y0,math.floor(center[1])+x0 )
        topSubdivision =  verticalS2(img,x0,x1,y0,center[0], iterations - 1)
        bottomSubdivision = verticalS2(img,x0,x1,center[0]+1,y1,iterations - 1)
        return [center] + topSubdivision + bottomSubdivision
    return []

def colorVector(img):
    
    black = len(np.where(img==[0,0,0])[0])
    red = len(np.where(img==[0,0,255])[0])
    green = len(np.where(img==[255,0,0])[0])
    blue = len(np.where(img==[0,255,0])[0])
    bColor1 = len(np.where(img==[155,159,255])[0])
    bColor2 = len(np.where(img==[100,96,0])[0])
    white = len(np.where(img==[255,255,255])[0])
    cyan = len(np.where(img==[255,255,0])[0])
    magenta = len(np.where(img==[0,255,255])[0])
    yellow = len(np.where(img==[255,0,255])[0])
    
    return { 'black':black, 'red':red, 'green':green, 'blue':blue, 'bColor1':bColor1, 'bColor2':bColor2, 'white':white, 'cyan':cyan, 'magenta':magenta, 'yellow':yellow }
          
